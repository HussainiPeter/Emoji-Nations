
import React from 'react';
import { Button } from './Button';
import { Difficulty, Category, User } from '../types';

interface StartScreenProps {
  onStart: () => void;
  onCreatePuzzle: () => void;
  onOpenSocial: () => void;
  onOpenLeaderboard: () => void;
  onOpenAuth: () => void;
  highScore: number;
  difficulty: Difficulty;
  setDifficulty: (d: Difficulty) => void;
  category: Category;
  setCategory: (c: Category) => void;
  currentUser: User | null;
}

const CATEGORIES: { id: Category; icon: string; label: string }[] = [
    { id: 'Countries', icon: '🌍', label: 'Countries' },
    { id: 'Bible', icon: '📖', label: 'Bible Stories' },
    { id: 'Movies', icon: '🎬', label: 'Movies' },
    { id: 'Stories', icon: '📚', label: 'Tales' },
    { id: 'Food', icon: '🍔', label: 'Food' },
    { id: 'Animals', icon: '🦁', label: 'Animals' },
];

export const StartScreen: React.FC<StartScreenProps> = ({ 
  onStart, 
  onCreatePuzzle,
  onOpenSocial,
  onOpenLeaderboard,
  onOpenAuth,
  highScore, 
  difficulty, 
  setDifficulty,
  category,
  setCategory,
  currentUser
}) => {
  return (
    <div className="h-full w-full flex flex-col items-center animate-fade-in relative font-sans overflow-y-auto bg-gray-50 scrollbar-hide">
      
      {/* Top Bar */}
      <div className="w-full flex justify-between items-center px-4 py-4 z-20 sticky top-0 bg-gray-50/90 backdrop-blur-sm">
        <button 
            onClick={onOpenAuth}
            className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-full shadow-sm hover:shadow-md transition-all text-sm font-bold text-gray-700 border border-gray-100"
        >
            <span className="text-lg">{currentUser ? currentUser.avatar : '👤'}</span>
            <span>{currentUser ? currentUser.username : 'Login'}</span>
        </button>
        
        <button 
            onClick={onOpenLeaderboard}
            className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-full shadow-sm hover:shadow-md transition-all text-sm font-bold text-gray-700 border border-gray-100"
        >
            <span>🏆</span>
            <span>Rankings</span>
        </button>
      </div>

      {/* Main Content */}
      <div className="w-full max-w-md flex flex-col items-center px-4 pb-20 space-y-6">
          {/* Hero Header */}
          <div className="text-center pt-4 pb-2">
            <div className="inline-block relative">
                <h1 className="text-6xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 drop-shadow-sm tracking-tight leading-tight select-none py-2">
                Emoji<br/>Riddles
                </h1>
                <div className="absolute -top-4 -right-6 text-4xl animate-bounce delay-700 select-none">🧩</div>
                <div className="absolute -bottom-2 -left-6 text-4xl animate-bounce delay-1000 select-none">🤔</div>
            </div>
          </div>

        {/* Main Game Card */}
        <div className="w-full bg-white rounded-3xl shadow-xl shadow-indigo-100/50 overflow-hidden border border-indigo-50 transform transition-all hover:scale-[1.01] duration-300">
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 h-2"></div>
            <div className="p-5 md:p-6">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-2xl font-black text-gray-800 flex items-center gap-2">
                        🎮 Arcade
                    </h2>
                    {highScore > 0 && (
                        <div className="bg-amber-100 text-amber-800 text-xs font-bold px-3 py-1 rounded-full border border-amber-200 flex items-center gap-1 shadow-sm">
                            🏆 Best: {highScore}
                        </div>
                    )}
                </div>

                {/* Category Grid */}
                <div className="mb-6">
                    <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Category</p>
                    <div className="grid grid-cols-3 gap-2">
                        {CATEGORIES.map((cat) => (
                            <button
                                key={cat.id}
                                onClick={() => setCategory(cat.id)}
                                className={`flex flex-col items-center justify-center p-2 rounded-xl border-2 transition-all aspect-square ${
                                    category === cat.id 
                                    ? 'border-indigo-500 bg-indigo-50 text-indigo-700 shadow-sm scale-105 z-10' 
                                    : 'border-gray-50 bg-gray-50 text-gray-400 hover:border-gray-200 hover:bg-white'
                                }`}
                            >
                                <span className="text-2xl mb-1">{cat.icon}</span>
                                <span className="text-[10px] font-bold leading-tight">{cat.label}</span>
                            </button>
                        ))}
                    </div>
                </div>

                {/* Difficulty */}
                <div className="bg-gray-100 p-1 rounded-xl flex mb-6">
                    {(['easy', 'medium', 'hard'] as Difficulty[]).map((d) => (
                        <button
                            key={d}
                            onClick={() => setDifficulty(d)}
                            className={`flex-1 py-2 text-xs font-bold rounded-lg capitalize transition-all duration-200 ${
                                difficulty === d 
                                ? 'bg-white text-indigo-600 shadow-sm ring-1 ring-black/5' 
                                : 'text-gray-400 hover:text-gray-600'
                            }`}
                        >
                            {d}
                        </button>
                    ))}
                </div>

                <Button 
                    onClick={onStart} 
                    size="lg" 
                    className="w-full text-lg py-4 shadow-indigo-300/50 shadow-lg hover:shadow-indigo-300/80 group"
                >
                    <span className="flex items-center justify-center gap-2 font-black tracking-wide">
                        PLAY NOW <span className="group-hover:translate-x-1 transition-transform">➡️</span>
                    </span>
                </Button>
            </div>
        </div>

        {/* Action Grid */}
        <div className="w-full grid grid-cols-2 gap-3">
             {/* Social Card */}
            <button 
                onClick={onOpenSocial}
                className="bg-white rounded-2xl p-4 shadow-md border border-green-50 flex flex-col items-center justify-center gap-2 hover:-translate-y-1 transition-transform group aspect-[4/3]"
            >
                <div className="w-10 h-10 rounded-full bg-green-50 flex items-center justify-center text-xl group-hover:scale-110 transition-transform text-green-600">
                    💬
                </div>
                <span className="font-bold text-gray-700 text-sm">Chat League</span>
            </button>

            {/* Puzzle Creator */}
            <button 
                onClick={onCreatePuzzle}
                className="bg-white rounded-2xl p-4 shadow-md border border-orange-50 flex flex-col items-center justify-center gap-2 hover:-translate-y-1 transition-transform group aspect-[4/3]"
            >
                <div className="w-10 h-10 rounded-full bg-orange-50 flex items-center justify-center text-xl group-hover:scale-110 transition-transform text-orange-600">
                    🧩
                </div>
                <span className="font-bold text-gray-700 text-sm">Create Puzzle</span>
            </button>
        </div>
      </div>
    </div>
  );
};
